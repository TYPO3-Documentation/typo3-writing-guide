.. include:: /Includes.rst.txt

Step 7: Publish
===============

After approval, you can move your post to the publishing pipeline. See
the\ `typo3.org Content Contribution
Workflow <https://docs.google.com/document/d/1kaWoSm05SX-ZWGDkY9sEWb-1GWvDmfrNd_5pzPvUGaE/edit\#heading=h.npgtr2a9snt7>`__\ .
